package piedrapapel;

public class Tirada {	
	String jugadoruno;//jugada producida por el jugador en contra
	
	String resultado; //resultado de la jugada del jugador 1 y el jugador 2 
	
	int rondaJugada;
	}




