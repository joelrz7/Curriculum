package piedrapapel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Scanner;

public class piedri {
	static int numeroRonda = 0;
//FUNCION PRINCIPAL	
	public static  void main(String[] args) {
		ArrayList<String> historial =new ArrayList<String>();
		File resultados =new File("resultados.txt");
		
		int sisjuego;//variable que recibira por porte del usuario el tipo de juego:
		//contra maquina o contra otro jugador
		Scanner sc = new Scanner(System.in); 
			int seguir;
			do {		
					
							System.out.println("Elige jugar contra pc (1) o jugar varias personas(2)");
							sisjuego = Integer.parseInt(sc.nextLine());//si no se pone todo se acumula el intro de la terminal para despues
							
						switch(sisjuego){
							case(1):
								String jugadorVariablepc = "PC";
									//CUIDADO añadir bucle do while con la variable del return que indica si se sigue jugando
									int jugadaunopc = (int)(Math.random() * (3 - 1) ) ;// numerorandomm entre 1  2 y 3
									int jugadadospc = juego();
									int ganadorpc=resultado(jugadaunopc,jugadadospc);
									String campeonpc = mostrarCampeon(ganadorpc,jugadorVariablepc);
									numeroRonda ++;
									//meter partida en un arraylist
									guardaArray(jugadorVariablepc,campeonpc,numeroRonda,historial);
									break;
								
								default:
									String jugadorVariable = "Jugador1";
									//CUIDADO añadir bucle do while con la variable del return que indica si se sigue jugando
									int jugadauno = juego();
									int jugadados = juego();
									int ganadoruser = resultado(jugadauno,jugadados);
									String campeon = mostrarCampeon(ganadoruser,jugadorVariable);
									numeroRonda ++;
									//meter partida en un arraylist
									guardaArray(jugadorVariable,campeon,numeroRonda,historial);
									break;
					 }
			
					
				do {		
					seguir = seguirJugando();	
				}while(seguir < 1 || seguir > 2);//este do while se repite mientras el numero introducdo no sea uno o dos, o lo que es lo mismo una respuesta valida
			
			}while(seguir!=1);//se repite el codigo mientras eljugador quiera continuar jugando
		
		
		
			System.out.println("Guardar resultados de las partidas (1)");	
			System.out.println("Revisar partidas anteriores (2)");
			System.out.println("Terminar (3)");
		
			Scanner scfin = new Scanner(System.in);
			int fin = scfin.nextInt();
			scfin.close();
			
		
			
			switch (fin) {
				case 1: 
					guardarPartida(historial,resultados);
					break;
				
				case 2: 
					listarPartidas(resultados);
					break;
				
				default:
					terminarPartida();
					break;
			
				
			}
		
	}
//METODOS	
	private static void terminarPartida() {
	System.out.println("Hasta Pronto");
	
}


	private static void listarPartidas(File a) {
	try {
		FileReader fr = new FileReader(a);
		int contador = fr.read();
		while (contador != -1) {
			
			System.out.print((char)contador);
			contador = fr.read();
		}
		fr.close();
		
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}

// AQUI HAY ERROR
	private static void guardaArray(String ju, String ca, int ro, ArrayList<String> a) {
	String b = ju+";"+ca+";"+ro;
	a.add(ro, b);
}


	private static int seguirJugando() {
			Scanner sca = new Scanner(System.in) ;
			int a;
			System.out.println("¿Desea seguir jugando? no(1) o si(2)");
			a = Integer.parseInt(sca.nextLine());
			sca.close();	
			if (a < 1 || a > 2){
					System.out.println("Introduzca una respuesta valida");
			}
			return a;
		
	
}


	
		
		public static void guardarPartida(ArrayList<String> a, File historial) {
			// crear un elemento de la clase tirada
			
			
			FileWriter fw;
			try {
				fw = new FileWriter(historial,true);
				for(int i = 1 ; i < a.size() ; i++)
					fw.write(a.get(i));
				
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	// CUIDADO BUSCAR MANERA DE METER TIRADA PASADA A CSV EN EL FICHERO DADO);
		}
			
		
		//public String toString(Tirada a) {
		//	return "";//CUIDADO FALTA DEVOLVER TODO
		//}


		private static String mostrarCampeon(int a , String b) {
			String ganador;
			switch(a) {
		
				case(1):
				String campeon1 = b;
				System.out.println("El ganador es el "+campeon1);
				ganador = b;
				
				break;
			default:
				System.out.println("El ganador es el Jugador2");
				ganador = "Jugador1" ;
				break;
				
				
		}
			return ganador;
	}

	private static int juego() {
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Introduzca su jugada piedra(1), papel(2) o tijera(3) :");
		int jugada = Integer.parseInt(sc.nextLine());
		sc.close();
		return jugada;//CUIDADO hay que sustituir return
		
	}//con este metodo voy a generar el juego
	
	private static int resultado(int a , int b) {
		int suma = a + b;
		int resto = suma % 2;
		int uno = 1;
		int dos = 2;
		int resultado;
		switch(resto) {
			case (0):
				resultado = uno;
				break;
		default:
				resultado = dos;
				break;
		}
		return resultado;
	}
	
}
